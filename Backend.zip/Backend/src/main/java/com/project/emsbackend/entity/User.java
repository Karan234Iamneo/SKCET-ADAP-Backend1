package com.project.emsbackend.entity;

public class User {
    
}
